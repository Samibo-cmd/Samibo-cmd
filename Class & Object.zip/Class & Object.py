class Student:
    # [assignment] Skeleton class. Add your code here
    def __init__(self, name, age, tracks, score):
        self.name = name
        self.age = age
        self.tracks = tracks
        self.score = score

    # Methods
    def change_name(self):
        print(f'{self.name} changed his name to Peter')
    def change_age(self):
        print(f'Bob changed his age from {self.age} to 34')
    def add_tracks(self):
        print(f'Bob added UT his track, he now has {self.tracks} and UT tracks')
    def get_score(self):
        print(f'Bob score is {self.score}')


Bob = Student('Bob', '26', ['FE', 'BE'], '20.90')
Bob.change_name()
Bob.change_age()
Bob.add_tracks()
Bob.get_score()